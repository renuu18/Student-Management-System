package com.example;
import java.sql.*;
import java.util.Scanner;

public class Module {
    public static void insert(Connection con,Scanner sc) throws SQLException {
        System.out.println("Enter the student roll number:");
        int rollNo=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the student name:");
        String name=sc.nextLine();
        System.out.println("Enter the student branch:");
        String branch=sc.nextLine();
        String sql="INSERT INTO student (rollno, name, branch) VALUES (?, ?, ?)";
        //to prevent security attack or SQL injection and clean code
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1, rollNo);
        ps.setString(2, name);
        ps.setString(3, branch);

        ps.executeUpdate();

        System.out.println("Student inserted successfully!");
    }
    public static void showData(Connection con) throws SQLException {
        PreparedStatement ps=con.prepareStatement("SELECT * FROM student");
        ResultSet rs=ps.executeQuery();
            while(rs.next()){
                System.out.print(rs.getInt("rollno") + " - ");
                System.out.print(rs.getString("name") + " - ");
                System.out.println(rs.getString("branch"));
            }
    }
    public static void deleteData(Connection con,Scanner sc) throws SQLException {
        System.out.println("Enter the student roll number to remove his data:");
        int rollNo=sc.nextInt();
        String sql="DELETE from student WHERE rollno=?";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1,rollNo);
        int rows=ps.executeUpdate();
        if (rows > 0) {
            System.out.println("Student deleted successfully!");
        } else {
            System.out.println("No student found with this roll number.");
        }
    }
    public static void updateData(Connection con, Scanner sc) {
        System.out.println("What do you want to update?");
        System.out.println("1. Roll number");
        System.out.println("2. Name");
        System.out.println("3. Branch");
        System.out.print("Enter your choice: ");

        int choice = sc.nextInt();
        sc.nextLine(); // fix buffer issue

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter previous roll number: ");
                    int prvRollNo = sc.nextInt();

                    System.out.print("Enter new roll number: ");
                    int newRollNo = sc.nextInt();

                    String sql1 = "UPDATE student SET rollno = ? WHERE rollno = ?";
                    PreparedStatement ps1 = con.prepareStatement(sql1);
                    ps1.setInt(1, newRollNo);
                    ps1.setInt(2, prvRollNo);

                    int rows1 = ps1.executeUpdate();

                    if (rows1 > 0) {
                        System.out.println("Roll number updated successfully!");
                    } else {
                        System.out.println("Student not found!");
                    }
                    break;

                case 2:
                    System.out.print("Enter roll number: ");
                    int rollNo2 = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter new name: ");
                    String name = sc.nextLine();

                    String sql2 = "UPDATE student SET name = ? WHERE rollno = ?";
                    PreparedStatement ps2 = con.prepareStatement(sql2);
                    ps2.setString(1, name);
                    ps2.setInt(2, rollNo2);

                    int rows2 = ps2.executeUpdate();

                    if (rows2 > 0) {
                        System.out.println("Name updated successfully!");
                    } else {
                        System.out.println("Student not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter roll number: ");
                    int rollNo3 = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter new branch: ");
                    String branch = sc.nextLine();

                    String sql3 = "UPDATE student SET branch = ? WHERE rollno = ?";
                    PreparedStatement ps3 = con.prepareStatement(sql3);
                    ps3.setString(1, branch);
                    ps3.setInt(2, rollNo3);

                    int rows3 = ps3.executeUpdate();

                    if (rows3 > 0) {
                        System.out.println("Branch updated successfully!");
                    } else {
                        System.out.println("Student not found!");
                    }
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}

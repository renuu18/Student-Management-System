package com.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import static java.lang.System.exit;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DbConnection dbConnection = new DbConnection();
        Connection con = dbConnection.connection();
        if (con == null) {
            System.out.println("Failed to connect to database");
            return;
        }
        System.out.println("Hello Welcome to Student Management System!!");
        System.out.println("Enter!!");
        while (true) {
            System.out.println("1.Insert Student data");
            System.out.println("2.Delete Student data");
            System.out.println("3.Update Student data");
            System.out.println("4.Show Student data");
            System.out.println("5.Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    try {
                        Module.insert(con, sc);
                    } catch (SQLException e) {
                        System.out.println("Database error: " + e.getMessage());
                    }
                    break;
                case 2:
                    try{
                        Module.deleteData(con,sc);
                    } catch (SQLException e) {
                        System.out.println("Database error: " + e.getMessage());
                    }
                    break;
                case 3:
                    Module.updateData(con,sc);
                    break;
                case 4:
                    try {
                        Module.showData(con);
                    } catch (SQLException e) {
                        System.out.println("Database error: " + e.getMessage());
                    }
                    break;
                case 5:
                    try {
                        con.close();
                        sc.close();
                        System.out.println("Exiting...");
                        return;
                    } catch (SQLException e) {
                        System.out.println("Database error: " + e.getMessage());
                    }
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
package com.example;
import java.sql.*;

public class DbConnection {
    public static Connection connection(){
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb","root","root");
        return con;
    } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

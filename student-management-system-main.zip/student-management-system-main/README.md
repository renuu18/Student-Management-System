# Student Management System

A Java-based console application using JDBC and MySQL to manage student records.

## Features
- Add student
- Delete student
- Update student
- View all students

## Technologies Used
- Java
- JDBC
- MySQL
- Maven

## Concepts Used
- PreparedStatement (prevents SQL Injection)
- CRUD Operations
- Exception Handling
- Database Connectivity
